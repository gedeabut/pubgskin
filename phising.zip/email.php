<?php
$emailkamu = 'gedeabut6@gmail.com';
?>