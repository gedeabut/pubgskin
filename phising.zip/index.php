<html>
<head>
<meta http-equiv="REFRESH" content="0;url=login.php">
</head>
<body>
</body>
</html>